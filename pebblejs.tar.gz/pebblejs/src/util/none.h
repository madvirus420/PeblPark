#pragma once

#define NONE
