#pragma once

#define NOOP ((void) 0)
