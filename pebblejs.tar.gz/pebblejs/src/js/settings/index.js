var Settings = require('./settings');

Settings.init();

module.exports = Settings;
