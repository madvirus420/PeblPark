var Clock = require('./clock');

module.exports = Clock;
